create view vwfacedata as
select `frsdb`.`tblusers`.`id`              AS `FaceID`,
       `frsdb`.`tblusers`.`thumbnailImage`  AS `FaceImage`,
       `frsdb`.`tblusers`.`featureData`     AS `FeatureData`,
       `frsdb`.`tblusers`.`createTime`      AS `CreateDate`,
       `frsdb`.`tblusers`.`gender`          AS `gender`,
       `frsdb`.`tblusers`.`nationality`     AS `nationality`,
       `frsdb`.`tblusers`.`dob`             AS `dob`,
       `frsdb`.`tblusers`.`type`            AS `type`,
       `frsdb`.`tblusers`.`referenceNumber` AS `referenceNumber`
from `frsdb`.`tblusers`;

